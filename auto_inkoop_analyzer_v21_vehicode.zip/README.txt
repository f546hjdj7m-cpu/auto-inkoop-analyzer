# Auto Inkoop Analyzer – VehiCode backend

Upload these items to the root of the GitHub repository:

- `index.html`
- `netlify.toml`
- folder `netlify/functions/decode-vin.mjs`

Netlify environment variable:
- `VEHICODE_API_KEY` = your VehiCode API key

After pushing to GitHub, trigger/redeploy the Netlify production deploy.
